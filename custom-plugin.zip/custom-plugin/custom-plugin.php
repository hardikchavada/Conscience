<?php
/**
* Plugin Name: Custom Plugin
* Version: 1.0
* Author: Hardik Chavada
* Description: This plugin generated custom post types (Articled).
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}


if ( ! function_exists( 'my_custom_article_post_type' ) ) {
    function my_custom_article_post_type() {
        $labels = array(
            'name'               => _x( 'Articles', 'post type general name' ),
            'singular_name'      => _x( 'Article', 'post type singular name' ),
            'add_new'            => _x( 'Add New', 'book' ),
            'add_new_item'       => __( 'Add New Article' ),
            'edit_item'          => __( 'Edit Article' ),
            'new_item'           => __( 'New Article' ),
            'all_items'          => __( 'All Articles' ),
            'view_item'          => __( 'View Article' ),
            'search_items'       => __( 'Search Articles' ),
            'not_found'          => __( 'No Articles found' ),
            'not_found_in_trash' => __( 'No Articles found in the Trash' ),         
            'menu_name'          => 'Articles'
        );
        $args = array(
            'labels'        => $labels,
            'description'   => 'Holds our Articles and Article specific data',
            'public'        => true,
            'menu_position' => 5,        
            'supports'      => array( 'title', 'editor', 'thumbnail', 'author' ),
            'has_archive'   => true,
            'menu_icon'     => 'dashicons-editor-alignleft',
        );

        register_post_type( 'article', $args ); 
    }
}
add_action( 'init', 'my_custom_article_post_type' );


// Add new custom user fields
if ( ! function_exists( 'extra_user_profile_fields' ) ) {
    function extra_user_profile_fields( $user ) { ?>
        <h3><?php _e("Extra profile information", "blank"); ?></h3>

        <table class="form-table">
            <!-- Address -->
        <tr>
            <th><label for="address"><?php _e("Address"); ?></label></th>
            <td>
                <input type="text" name="address" id="address" value="<?php echo esc_attr( get_the_author_meta( 'address', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your address."); ?></span>
            </td>
        </tr>
        <!-- Street -->
        <tr>
            <th><label for="address"><?php _e("Street"); ?></label></th>
            <td>
                <input type="text" name="street" id="street" value="<?php echo esc_attr( get_the_author_meta( 'street', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your Street."); ?></span>
            </td>
        </tr>
        <!-- Suit -->
        <tr>
            <th><label for="address"><?php _e("Suit"); ?></label></th>
            <td>
                <input type="text" name="suit" id="suit" value="<?php echo esc_attr( get_the_author_meta( 'suit', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your Suit."); ?></span>
            </td>
        </tr>
        <!-- City -->
        <tr>
            <th><label for="city"><?php _e("City"); ?></label></th>
            <td>
                <input type="text" name="city" id="city" value="<?php echo esc_attr( get_the_author_meta( 'city', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your city."); ?></span>
            </td>
        </tr>
        <!-- Pincode -->
        <tr>
        <th><label for="pincode"><?php _e("Pin Code"); ?></label></th>
            <td>
                <input type="text" name="pincode" id="pincode" value="<?php echo esc_attr( get_the_author_meta( 'pincode', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your Pin Code."); ?></span>
            </td>
        </tr>
        <!-- Phone -->
        <tr>
            <th><label for="address"><?php _e("Phone"); ?></label></th>
            <td>
                <input type="text" name="phone" id="phone" value="<?php echo esc_attr( get_the_author_meta( 'phone', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your Phone."); ?></span>
            </td>
        </tr>
        <!-- Company Name -->
        <tr>
            <th><label for="address"><?php _e("Company Name"); ?></label></th>
            <td>
                <input type="text" name="company_name" id="company_name" value="<?php echo esc_attr( get_the_author_meta( 'company_name', $user->ID ) ); ?>" class="regular-text" /><br />
                <span class="description"><?php _e("Please enter your Company Name."); ?></span>
            </td>
        </tr>
        
        </table>
    <?php 
    }
}
add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );



//Save user fields
if ( ! function_exists( 'save_extra_user_profile_fields' ) ) {
    function save_extra_user_profile_fields( $user_id ) {
        if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-user_' . $user_id ) ) {
            return;
        }
        
        if ( !current_user_can( 'edit_user', $user_id ) ) { 
            return false; 
        }
        //update default data
        update_user_meta( $user_id, 'url', $_POST['url'] );
        update_user_meta( $user_id, 'email', $_POST['email'] );
        update_user_meta( $user_id, 'display_name', $_POST['display_name'] );
        //custom data 
        update_user_meta( $user_id, 'address', $_POST['address'] );
        update_user_meta( $user_id, 'street', $_POST['street'] );
        update_user_meta( $user_id, 'suit', $_POST['suit'] );
        update_user_meta( $user_id, 'city', $_POST['city'] );
        update_user_meta( $user_id, 'pincode', $_POST['pincode'] );
        update_user_meta( $user_id, 'phone', $_POST['phone'] );
        update_user_meta( $user_id, 'company_name', $_POST['company_name'] );
    }
}
add_action( 'personal_options_update', 'save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'save_extra_user_profile_fields' );


//add submenu page
if ( ! function_exists( 'custom_add_submenu_page' ) ) {
    function custom_add_submenu_page() {    
        add_submenu_page(
            'edit.php?post_type=article',
            __( 'Fetch Data', 'cutom-plugin' ),
            __( 'Fetch Data', 'cutom-plugin' ),
            'manage_options',
            'fetch-data',
            'fetch_data_page_callback'
        );
    }
}
add_action( 'admin_menu', 'custom_add_submenu_page' );

//submenu callback
function fetch_data_page_callback() {
    include( plugin_dir_path( __FILE__ ) . 'inc/fetch-data.php');
}