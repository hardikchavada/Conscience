<style>
#fetch_btns {
display:flex;
justify-content:center;
align-content:center;
}

.fetch_api {
	height:40px;
	width:150px;
	margin:20px;
}
</style>
<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

?>
	<form method="post" id="fetch_btns"> 
		<button name="fetch_users" class="fetch_api">Fetch Users</button>
		<button name="fetch_articles" class="fetch_api">Fetch Articles</button>
	</form>
<?php

if(isset($_POST['fetch_users'])) {

	$url = "https://jsonplaceholder.typicode.com/users";
	
	$request = wp_remote_get( $url );
	
	if( is_wp_error( $request ) ) {
		return false; // Bail early
	}
	
	$body = wp_remote_retrieve_body( $request );
	
	$users = json_decode( $body );

	foreach($users as $user) {
		$name = $user->name;
		$username = $user->username;	
		$email = $user->email;
		$street = $user->address->street;	
		$suite = $user->address->suite;
		$pincode = $user->address->zipcode;
		$phone = $user->phone;
		$website = $user->website;
		$arr = [
			$name, $username, $email, $street, $suite, $pincode, $phone, $website
		];
		
		$inserted = wp_insert_user([
			'user_pass' => md5($name),
			'user_login' => $username,
			'user_email' => $email,
			'role' => 'author'
		]);
	}
	echo "<h1>Users fetched successfully</h1>";	
}

//Fetch Articles
if(isset($_POST['fetch_articles'])) {
	
	$args = array( 
		'role__in' => array('author') 
	);

	$get_author_users = get_users( $args );	
	$authors_array = array();

	foreach($get_author_users as $a_user) {
		$post_id = $a_user->data->ID;			
		array_push($authors_array, $post_id);
	}	

	//fetch posts from API
	$posts_url = "https://jsonplaceholder.typicode.com/posts";	
	$post_request = wp_remote_get( $posts_url );
	
	if( is_wp_error( $post_request ) ) {
		return false; // Bail early
	}
	
	$body = wp_remote_retrieve_body( $post_request );
	
	$posts = json_decode( $body );

	foreach($posts as $post) {
		$ran = array_rand($authors_array);
		$author_id = $authors_array[$ran];		

		$post_title = $post->title;
		$content = $post->body;
	
		// Create post object
		$my_post = array(
			'post_title'    => $post_title,
			'post_content'  => $content,
			'post_status'   => 'publish',
			'post_author'   => $author_id,
			'post_type'  	=> 'article',		
		);	
		// Insert the post into the database
		wp_insert_post( $my_post );		
	}
	echo "<h1>Articles updated successfully</h1>";
}
